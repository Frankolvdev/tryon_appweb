import type { ReactNode } from "react";

const items = [
  ["shield", "Cuenta protegida"],
  ["lock", "Sesión segura"],
  ["activity", "Procesamiento privado"],
  ["database", "Datos en tiempo real"],
] as const;

function Icon({ name }: { name: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      {name === "brand" && (
        <>
          <path d="M12 2.8 13.7 9l6.2 1.7-6.2 1.7L12 18.6l-1.7-6.2-6.2-1.7L10.3 9 12 2.8Z" />
          <path d="m17.2 3.8.7 2.4 2.4.7-2.4.7-.7 2.4-.7-2.4-2.4-.7 2.4-.7.7-2.4Z" />
        </>
      )}
      {name === "shield" && (
        <>
          <path d="M12 3 5 6v5c0 4.7 2.9 8.1 7 10 4.1-1.9 7-5.3 7-10V6l-7-3Z" />
          <path d="m9.5 12 1.7 1.7 3.6-3.9" />
        </>
      )}
      {name === "lock" && (
        <>
          <rect x="5" y="10" width="14" height="10" rx="2" />
          <path d="M8 10V7a4 4 0 0 1 8 0v3" />
        </>
      )}
      {name === "activity" && <path d="M3 12h4l2-6 4 12 2-6h6" />}
      {name === "database" && (
        <>
          <ellipse cx="12" cy="5" rx="8" ry="3" />
          <path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5" />
          <path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6" />
        </>
      )}
    </svg>
  );
}

function Brand() {
  return (
    <div className="luxiaBrand">
      <div className="luxiaBrandMark"><Icon name="brand" /></div>
      <div className="luxiaBrandText">
        <strong>LUXIA</strong>
        <span>AI FASHION STUDIO</span>
      </div>
    </div>
  );
}

export function AuthShell({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <main className="luxiaAuthPage">
      <div className="luxiaAuthGrid" />
      <div className="luxiaGlow luxiaGlowTop" />
      <div className="luxiaGlow luxiaGlowBottom" />

      <div className="luxiaAuthLayout">
        <section className="luxiaHero">
          <Brand />

          <div className="luxiaHeroContent">
            <p className="luxiaSectionLabel">ESTUDIO CREATIVO</p>
            <h1>
              Imagina,
              <br />
              crea y transforma.
            </h1>
            <p className="luxiaHeroDescription">{description}</p>
          </div>

          <div className="luxiaSecurityGrid">
            {items.map(([icon, label]) => (
              <div className="luxiaSecurityItem" key={label}>
                <Icon name={icon} />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="luxiaFormSide">
          <div className="luxiaMobileBrand"><Brand /></div>

          <div className="luxiaFormWrap">
            <div className="luxiaAuthCard">
              <div className="luxiaLockIcon"><Icon name="lock" /></div>
              <p className="luxiaAccessLabel">ACCESO DE USUARIO</p>
              <h2>{title}</h2>
              <p className="luxiaSubtitle">{eyebrow}</p>
              {children}
            </div>
            <p className="luxiaAuditText">
              Tu sesión y tus operaciones quedan protegidas por los controles de seguridad de la plataforma.
            </p>
          </div>
        </section>
      </div>
    </main>
  );
}
