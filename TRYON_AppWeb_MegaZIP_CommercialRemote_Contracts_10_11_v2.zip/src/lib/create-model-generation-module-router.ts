import type { GenerationExecutionEngine, GenerationModule } from "@/types/generation";

export type CreateModelIdentityMode = "create" | "existing";
export type CreateModelExecutionAudience =
  | "commercial_remote"
  | "commercial_local"
  | "owner_local";

type ExpectedInput = {
  key: string;
  name: string;
  type: "float" | "integer" | "text" | "image";
  required: boolean;
};

type ExpectedOutput = {
  key: "output_1" | "output_2";
  name: string;
  type: "image";
  required: boolean;
};

export type GenerationModuleContract = {
  moduleId: number;
  key: string;
  name: string;
  version?: number;
  allowedEngines?: readonly GenerationExecutionEngine[];
  inputs: readonly ExpectedInput[];
  outputs: readonly ExpectedOutput[];
};

const LOCAL_CREATE_V5_INPUTS = [
  { key: "input_1", name: "prompt head", type: "text", required: true },
  { key: "input_2", name: "complexion", type: "integer", required: true },
  { key: "input_4", name: "Seed Body", type: "integer", required: true },
  { key: "input_5", name: "Seed Head", type: "integer", required: true },
  { key: "input_6", name: "ass", type: "float", required: true },
  { key: "input_7", name: "breasts", type: "float", required: true },
  { key: "input_8", name: "waist", type: "float", required: true },
  { key: "input_9", name: "skin tone", type: "float", required: true },
  { key: "input_10", name: "height", type: "float", required: true },
  { key: "input_11", name: "bubble butt", type: "float", required: true },
  { key: "input_12", name: "hair length", type: "float", required: true },
  { key: "input_13", name: "pose", type: "text", required: true },
  { key: "input_14", name: "view", type: "text", required: true },
  { key: "input_15", name: "action", type: "text", required: true },
  { key: "input_16", name: "place", type: "text", required: true },
  { key: "input_17", name: "time_weather_lighting", type: "text", required: true },
  { key: "input_18", name: "clothes", type: "text", required: true },
  { key: "input_19", name: "extra_details", type: "text", required: true },
  { key: "input_20", name: "hips", type: "text", required: true },
  { key: "input_21", name: "face_reference", type: "image", required: true },
  { key: "input_22", name: "ancestry", type: "text", required: true },
  { key: "input_23", name: "hair style", type: "text", required: true },
  { key: "input_24", name: "face_reference2", type: "image", required: true },
  { key: "input_25", name: "age", type: "float", required: true },
  { key: "input_26", name: "hair_volumen", type: "float", required: true },
  { key: "input_27", name: "prompt_face_swap", type: "text", required: true },
  { key: "input_28", name: "is_african", type: "integer", required: true },
] as const satisfies readonly ExpectedInput[];

const CREATE_MODEL_OUTPUTS = [
  { key: "output_1", name: "all body", type: "image", required: true },
  { key: "output_2", name: "head", type: "image", required: true },
] as const satisfies readonly ExpectedOutput[];

const OWNER_LOCAL_ENGINES = ["local_docker", "owner_local"] as const satisfies readonly GenerationExecutionEngine[];
const COMMERCIAL_LOCAL_ENGINES = ["local_docker"] as const satisfies readonly GenerationExecutionEngine[];

const LOCAL_CREATE_BASE = {
  moduleId: 8,
  key: "create_model_woman",
  name: "Create Model Woman Owner V2",
  version: 5,
  inputs: LOCAL_CREATE_V5_INPUTS,
  outputs: CREATE_MODEL_OUTPUTS,
} as const;

const LOCAL_EXISTING_V6_INPUTS = [
  { key: "input_2", name: "complexion", type: "integer", required: true },
  { key: "input_4", name: "Seed Body", type: "integer", required: true },
  { key: "input_5", name: "Seed Head", type: "integer", required: true },
  { key: "input_6", name: "ass", type: "float", required: true },
  { key: "input_7", name: "breasts", type: "float", required: true },
  { key: "input_8", name: "waist", type: "float", required: true },
  { key: "input_9", name: "skin tone", type: "float", required: true },
  { key: "input_10", name: "height", type: "float", required: true },
  { key: "input_11", name: "bubble butt", type: "float", required: true },
  { key: "input_12", name: "hair length", type: "float", required: true },
  { key: "input_13", name: "pose", type: "text", required: true },
  { key: "input_14", name: "view", type: "text", required: true },
  { key: "input_15", name: "action", type: "text", required: true },
  { key: "input_16", name: "place", type: "text", required: true },
  { key: "input_17", name: "time_weather_lighting", type: "text", required: true },
  { key: "input_18", name: "clothes", type: "text", required: true },
  { key: "input_19", name: "extra_details", type: "text", required: true },
  { key: "input_20", name: "hips", type: "text", required: true },
  { key: "input_21", name: "head", type: "image", required: true },
  { key: "input_22", name: "ancestry", type: "text", required: true },
  { key: "input_23", name: "age", type: "float", required: true },
  { key: "input_24", name: "hair_style", type: "text", required: true },
  { key: "input_25", name: "hair_volumen", type: "float", required: true },
] as const satisfies readonly ExpectedInput[];

const REMOTE_CREATE_V7_INPUTS = [
  { key: "input_1", name: "prompt head", type: "text", required: true },
  { key: "input_2", name: "complexion", type: "integer", required: true },
  { key: "input_4", name: "Seed Body", type: "integer", required: true },
  { key: "input_5", name: "Seed Head", type: "integer", required: true },
  { key: "input_6", name: "ass", type: "float", required: true },
  { key: "input_7", name: "breasts", type: "float", required: true },
  { key: "input_8", name: "waist", type: "float", required: true },
  { key: "input_9", name: "skin tone", type: "float", required: true },
  { key: "input_10", name: "height", type: "float", required: true },
  { key: "input_11", name: "bubble butt", type: "float", required: true },
  { key: "input_12", name: "hair length", type: "float", required: true },
  { key: "input_13", name: "pose", type: "text", required: true },
  { key: "input_14", name: "view", type: "text", required: true },
  { key: "input_15", name: "action", type: "text", required: true },
  { key: "input_16", name: "place", type: "text", required: true },
  { key: "input_17", name: "time_weather_lighting", type: "text", required: true },
  { key: "input_18", name: "clothes", type: "text", required: true },
  { key: "input_19", name: "extra_details", type: "text", required: true },
  { key: "input_20", name: "hips", type: "text", required: true },
  { key: "input_21", name: "face_reference", type: "image", required: true },
  { key: "input_22", name: "ancestry", type: "text", required: true },
  { key: "input_23", name: "hair style", type: "text", required: true },
  { key: "input_24", name: "face_reference2", type: "image", required: true },
  { key: "input_25", name: "age", type: "float", required: true },
  { key: "input_26", name: "hair_volumen", type: "float", required: true },
  { key: "input_27", name: "prompt_face_swap", type: "text", required: true },
  { key: "input_28", name: "is_african", type: "integer", required: true },
] as const satisfies readonly ExpectedInput[];

const REMOTE_EXISTING_V8_INPUTS = [
  { key: "input_2", name: "complexion", type: "integer", required: true },
  { key: "input_4", name: "Seed Body", type: "integer", required: true },
  { key: "input_5", name: "Seed Head", type: "integer", required: true },
  { key: "input_6", name: "ass", type: "float", required: true },
  { key: "input_7", name: "breasts", type: "float", required: true },
  { key: "input_8", name: "waist", type: "float", required: true },
  { key: "input_9", name: "skin tone", type: "float", required: true },
  { key: "input_10", name: "height", type: "float", required: true },
  { key: "input_11", name: "bubble butt", type: "float", required: true },
  { key: "input_12", name: "hair length", type: "float", required: true },
  { key: "input_13", name: "pose", type: "text", required: true },
  { key: "input_14", name: "view", type: "text", required: true },
  { key: "input_15", name: "action", type: "text", required: true },
  { key: "input_16", name: "place", type: "text", required: true },
  { key: "input_17", name: "time_weather_lighting", type: "text", required: true },
  { key: "input_18", name: "clothes", type: "text", required: true },
  { key: "input_19", name: "extra_details", type: "text", required: true },
  { key: "input_20", name: "hips", type: "text", required: true },
  { key: "input_21", name: "head", type: "image", required: true },
  { key: "input_22", name: "ancestry", type: "text", required: true },
  { key: "input_23", name: "age", type: "float", required: true },
  { key: "input_24", name: "hair_style", type: "text", required: true },
  { key: "input_25", name: "hair_volumen", type: "float", required: true },
] as const satisfies readonly ExpectedInput[];

const REMOTE_CREATE_CONTRACT = {
  moduleId: 10,
  key: "create_model_woman",
  name: "Create Model Woman  V2",
  version: 7,
  inputs: REMOTE_CREATE_V7_INPUTS,
  outputs: CREATE_MODEL_OUTPUTS,
} as const satisfies GenerationModuleContract;

const REMOTE_EXISTING_CONTRACT = {
  moduleId: 11,
  key: "create_model_woman",
  name: "Create Model Woman From Head  V2",
  version: 8,
  inputs: REMOTE_EXISTING_V8_INPUTS,
  outputs: CREATE_MODEL_OUTPUTS,
} as const satisfies GenerationModuleContract;

const LOCAL_EXISTING_BASE = {
  moduleId: 9,
  key: "create_model_woman",
  name: "Create Model Woman From Head Owner V2",
  version: 6,
  inputs: LOCAL_EXISTING_V6_INPUTS,
  outputs: CREATE_MODEL_OUTPUTS,
} as const;

/**
 * Central routing table for Create Model IA.
 *
 * Important separation:
 * - commercial_remote: modules 10/11 using the published Create/From Head V2 contracts on remote providers.
 * - commercial_local: modules 8/9 only when they are published as local_docker.
 *   Backend keeps accounting_mode=commercial, so tokens/pricing stay normal.
 * - owner_local: the same local-optimized modules 8/9. Backend independently
 *   forces engine=owner_local and accounting_mode=owner_private.
 *
 * AppWeb only chooses the module contract. It never decides billing/accounting.
 */
export const CREATE_MODEL_GENERATION_CONTRACTS = {
  commercial_remote: {
    create: REMOTE_CREATE_CONTRACT,
    existing: REMOTE_EXISTING_CONTRACT,
  },
  commercial_local: {
    create: {
      ...LOCAL_CREATE_BASE,
      allowedEngines: COMMERCIAL_LOCAL_ENGINES,
    },
    existing: {
      ...LOCAL_EXISTING_BASE,
      allowedEngines: COMMERCIAL_LOCAL_ENGINES,
    },
  },
  owner_local: {
    create: {
      ...LOCAL_CREATE_BASE,
      allowedEngines: OWNER_LOCAL_ENGINES,
    },
    existing: {
      ...LOCAL_EXISTING_BASE,
      allowedEngines: OWNER_LOCAL_ENGINES,
    },
  },
} as const satisfies Record<
  CreateModelExecutionAudience,
  Record<CreateModelIdentityMode, GenerationModuleContract>
>;

function contractError(contract: GenerationModuleContract, detail: string): Error {
  return new Error(`El contrato de "${contract.name}" no coincide: ${detail}`);
}

export function assertGenerationModuleMatchesContract(
  module: GenerationModule,
  contract: GenerationModuleContract,
): void {
  if (module.id !== contract.moduleId) {
    throw contractError(contract, `se esperaba module_id=${contract.moduleId} y llegó ${module.id}.`);
  }
  if (module.key !== contract.key) {
    throw contractError(contract, `se esperaba key="${contract.key}" y llegó "${module.key}".`);
  }
  if (contract.version !== undefined && module.version !== contract.version) {
    throw contractError(contract, `se esperaba versión ${contract.version} y llegó ${module.version}.`);
  }
  if (
    contract.allowedEngines &&
    !contract.allowedEngines.includes(module.default_execution_engine)
  ) {
    throw contractError(
      contract,
      `el engine "${module.default_execution_engine}" no coincide con esta ruta. Esperado: ${contract.allowedEngines.join(" / ")}.`,
    );
  }

  for (const expected of contract.inputs) {
    const actual = module.inputs.find((input) => input.key === expected.key);
    if (!actual) {
      throw contractError(contract, `falta ${expected.key} (${expected.name}).`);
    }
    if (actual.input_type !== expected.type) {
      throw contractError(
        contract,
        `${expected.key} cambió de tipo: se esperaba ${expected.type} y llegó ${actual.input_type}.`,
      );
    }
    if (actual.is_required !== expected.required) {
      throw contractError(
        contract,
        `${expected.key} cambió obligatoriedad: se esperaba ${expected.required ? "obligatorio" : "opcional"}.`,
      );
    }
  }

  for (const expected of contract.outputs) {
    const actual = module.outputs.find((output) => output.key === expected.key);
    if (!actual) {
      throw contractError(contract, `falta ${expected.key} (${expected.name}).`);
    }
    if (actual.output_type !== expected.type) {
      throw contractError(
        contract,
        `${expected.key} cambió de tipo: se esperaba ${expected.type} y llegó ${actual.output_type}.`,
      );
    }
    if (actual.is_required !== expected.required) {
      throw contractError(
        contract,
        `${expected.key} cambió obligatoriedad: se esperaba ${expected.required ? "obligatorio" : "opcional"}.`,
      );
    }
  }
}

/**
 * The active local_docker publication is the switch for commercial-local.
 * Keeping modules 8/9 inactive (or not local_docker) preserves the historical
 * 10/11 path for ordinary users. Owner is always routed to 8/9; Backend then
 * forces owner_local independently of the module's published engine.
 */
export function createModelAudience(
  modules: readonly GenerationModule[],
  isOwner: boolean,
  identityMode: CreateModelIdentityMode,
): CreateModelExecutionAudience {
  if (isOwner) return "owner_local";

  const localContract = CREATE_MODEL_GENERATION_CONTRACTS.commercial_local[identityMode];
  const localModule = modules.find((item) => item.id === localContract.moduleId);

  if (
    localModule?.is_active &&
    localModule.default_execution_engine === "local_docker"
  ) {
    return "commercial_local";
  }

  return "commercial_remote";
}

export function createModelContract(
  modules: readonly GenerationModule[],
  isOwner: boolean,
  identityMode: CreateModelIdentityMode,
): GenerationModuleContract {
  return CREATE_MODEL_GENERATION_CONTRACTS[
    createModelAudience(modules, isOwner, identityMode)
  ][identityMode];
}

export function resolveCreateModelGenerationModule(
  modules: readonly GenerationModule[],
  {
    isOwner,
    identityMode,
    requireActive = true,
  }: {
    isOwner: boolean;
    identityMode: CreateModelIdentityMode;
    requireActive?: boolean;
  },
): GenerationModule {
  const audience = createModelAudience(modules, isOwner, identityMode);
  const contract = CREATE_MODEL_GENERATION_CONTRACTS[audience][identityMode];
  const module = modules.find((item) => item.id === contract.moduleId);

  if (!module || (requireActive && !module.is_active)) {
    throw new Error(
      `No se encontró activo "${contract.name}" (módulo ${contract.moduleId}) para la ruta ${audience}.`,
    );
  }

  // Fail closed when a local module is published for commercial use but its
  // contract drifted. We never silently send that request to another workflow.
  assertGenerationModuleMatchesContract(module, contract);
  return module;
}

export function tryResolveCreateModelGenerationModule(
  modules: readonly GenerationModule[],
  options: {
    isOwner: boolean;
    identityMode: CreateModelIdentityMode;
    requireActive?: boolean;
  },
): GenerationModule | null {
  try {
    return resolveCreateModelGenerationModule(modules, options);
  } catch {
    return null;
  }
}
