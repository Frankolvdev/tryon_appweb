import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "@/components/auth/login-form";
export default function LoginPage(){return <AuthShell eyebrow="Bienvenido de nuevo" title="Accede a tu estudio" description="Continúa creando, administrando y guardando tus resultados."><LoginForm/></AuthShell>}
