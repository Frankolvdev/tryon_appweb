import type { ReactNode } from "react";

const items = [
  { icon: "shield", label: "Cuenta protegida" },
  { icon: "lock", label: "Sesión segura" },
  { icon: "activity", label: "Procesamiento privado" },
  { icon: "database", label: "Datos en tiempo real" },
] as const;

function LineIcon({ name }: { name: string }) {
  if (name === "shield") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 5 6v5c0 4.7 2.9 8.1 7 10 4.1-1.9 7-5.3 7-10V6l-7-3Z"/><path d="m9.5 12 1.7 1.7 3.6-3.9"/></svg>;
  if (name === "lock") return <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>;
  if (name === "activity") return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12h4l2-7 4 14 2-7h6"/></svg>;
  return <svg viewBox="0 0 24 24" aria-hidden="true"><ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></svg>;
}

function LuxiaLogo() {
  return (
    <div className="luxiaAuthBrand" aria-label="LUXIA AI Fashion Studio">
      <span className="luxiaAuthLogoMark" aria-hidden="true">
        <svg viewBox="0 0 24 24"><path d="M12 2.8 13.35 8l5.2 1.35-5.2 1.35L12 15.9l-1.35-5.2-5.2-1.35L10.65 8 12 2.8Z"/><path d="m18.3 14.2.75 2.6 2.55.7-2.55.7-.75 2.6-.75-2.6-2.55-.7 2.55-.7.75-2.6Z"/><path d="M5.5 3.8v3.4M3.8 5.5h3.4"/></svg>
      </span>
      <span className="luxiaAuthBrandText"><strong>LUXIA</strong><small>AI FASHION STUDIO</small></span>
    </div>
  );
}

export function AuthShell({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children: ReactNode }) {
  return (
    <main className="luxiaAuthPage">
      <section className="luxiaAuthHero">
        <LuxiaLogo />
        <div className="luxiaAuthHeroCopy">
          <p className="luxiaAuthKicker">ESTUDIO CREATIVO</p>
          <h1>Tu estilo,<br />sin límites.</h1>
          <p className="luxiaAuthDescription">Transforma fotografías y prendas en resultados únicos mediante inteligencia artificial.</p>
        </div>
        <div className="luxiaAuthFeatureGrid">
          {items.map((item) => (
            <div className="luxiaAuthFeature" key={item.label}>
              <span><LineIcon name={item.icon} /></span>
              <small>{item.label}</small>
            </div>
          ))}
        </div>
      </section>

      <section className="luxiaAuthFormSide">
        <div className="luxiaAuthCard">
          <div className="luxiaAuthLockBadge"><LineIcon name="lock" /></div>
          <p className="luxiaAuthAccessLabel">ACCESO DE USUARIO</p>
          <h2>{title}</h2>
          <p className="luxiaAuthCardDescription">{description}</p>
          {children}
        </div>
        <p className="luxiaAuthAudit">Tu sesión y tus operaciones quedan protegidas por los controles de seguridad de la plataforma.</p>
      </section>
    </main>
  );
}
