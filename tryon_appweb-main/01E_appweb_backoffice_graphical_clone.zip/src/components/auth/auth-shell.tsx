import type { ReactNode } from "react";

const features = [
  { icon: "shield", label: "Cuenta protegida" },
  { icon: "lock", label: "Sesión segura" },
  { icon: "activity", label: "Procesamiento privado" },
  { icon: "database", label: "Resultados en tiempo real" },
] as const;

function LineIcon({ name }: { name: string }) {
  const paths: Record<string, ReactNode> = {
    shield: <><path d="M12 3 5 6v5c0 4.7 2.9 8.1 7 10 4.1-1.9 7-5.3 7-10V6l-7-3Z"/><path d="m9.5 12 1.7 1.7 3.6-3.9"/></>,
    lock: <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    activity: <path d="M3 12h4l2.2-6 4.3 12 2.2-6H21"/>,
    database: <><ellipse cx="12" cy="5" rx="7" ry="3"/><path d="M5 5v6c0 1.7 3.1 3 7 3s7-1.3 7-3V5"/><path d="M5 11v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/></>,
  };
  return <svg viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

function SparkLogo() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="m12 2 1.55 5.45L19 9l-5.45 1.55L12 16l-1.55-5.45L5 9l5.45-1.55L12 2Z" />
      <path d="m18.2 14.2.9 2.7 2.7.9-2.7.9-.9 2.7-.9-2.7-2.7-.9 2.7-.9.9-2.7Z" />
      <path d="M4.6 4.8h2.8M6 3.4v2.8" />
    </svg>
  );
}

function Brand() {
  return (
    <div className="luxiaAuthBrand">
      <span className="luxiaAuthLogo"><SparkLogo /></span>
      <span className="luxiaAuthBrandText">
        <strong>LUXIA</strong>
        <small>AI FASHION STUDIO</small>
      </span>
    </div>
  );
}

export function AuthShell({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow: string;
  title: string;
  description: string;
  children: ReactNode;
}) {
  return (
    <main className="luxiaAuthPage">
      <section className="luxiaAuthHero">
        <Brand />

        <div className="luxiaAuthHeroCopy">
          <p className="luxiaAuthKicker">ESTUDIO CREATIVO</p>
          <h1>Imagina, crea<br />y transforma.</h1>
          <p>{description}</p>
        </div>

        <div className="luxiaAuthFeatures">
          {features.map((item) => (
            <div key={item.label} className="luxiaAuthFeature">
              <LineIcon name={item.icon} />
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="luxiaAuthFormSide">
        <div className="luxiaAuthCardColumn">
          <div className="luxiaAuthCard">
            <span className="luxiaAuthLock"><LineIcon name="lock" /></span>
            <p className="luxiaAuthAccess">ACCESO DE USUARIO</p>
            <h2>{title}</h2>
            <p className="luxiaAuthIntro">{eyebrow}</p>
            {children}
          </div>
          <p className="luxiaAuthAudit">Tu sesión y tus operaciones quedan protegidas por los controles de seguridad de la plataforma.</p>
        </div>
      </section>
    </main>
  );
}
