"use client";

import { env } from "@/lib/env";

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.4-.18-2.07H12v3.91h5.38a4.6 4.6 0 0 1-2 3.02v2.54h3.24c1.9-1.75 2.98-4.32 2.98-7.4Z"/>
      <path fill="#34A853" d="M12 22c2.7 0 4.97-.9 6.62-2.37l-3.24-2.54c-.9.6-2.05.96-3.38.96-2.61 0-4.82-1.76-5.61-4.13H3.04v2.62A10 10 0 0 0 12 22Z"/>
      <path fill="#FBBC05" d="M6.39 13.92A6 6 0 0 1 6.07 12c0-.67.11-1.32.32-1.92V7.46H3.04A10 10 0 0 0 2 12c0 1.61.38 3.14 1.04 4.54l3.35-2.62Z"/>
      <path fill="#EA4335" d="M12 5.95c1.47 0 2.8.51 3.84 1.5l2.88-2.88A9.64 9.64 0 0 0 12 2a10 10 0 0 0-8.96 5.46l3.35 2.62C7.18 7.71 9.39 5.95 12 5.95Z"/>
    </svg>
  );
}

export function SocialProviders() {
  const startGoogle = () => {
    if (!env.googleOAuthStartUrl) {
      window.alert("Google OAuth aún no está configurado.\nCompleta NEXT_PUBLIC_GOOGLE_OAUTH_START_URL siguiendo GOOGLE_OAUTH_SETUP.md.");
      return;
    }
    const returnTo = encodeURIComponent(`${env.appUrl}/oauth/callback`);
    const separator = env.googleOAuthStartUrl.includes("?") ? "&" : "?";
    window.location.assign(`${env.googleOAuthStartUrl}${separator}return_to=${returnTo}`);
  };

  return (
    <div className="luxiaSocialBlock">
      <button type="button" className="luxiaGoogleButton" onClick={startGoogle}>
        <GoogleIcon />
        <span>Continuar con Google</span>
      </button>
      <div className="luxiaAuthDivider"><span>o continúa con correo</span></div>
    </div>
  );
}
