"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { login } from "@/lib/auth-api";
import { saveSession } from "@/lib/auth-storage";
import { SocialProviders } from "@/components/auth/social-providers";

function MailIcon() { return <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>; }
function LockIcon() { return <svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>; }
function EyeIcon() { return <svg viewBox="0 0 24 24"><path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/></svg>; }

export function LoginForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    setLoading(true);
    const data = new FormData(event.currentTarget);
    try {
      const token = await login(String(data.get("email")), String(data.get("password")));
      saveSession(token.access_token, token.refresh_token);
      router.replace("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "No fue posible iniciar sesión.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <SocialProviders />
      <form onSubmit={submit} className="luxiaAuthForm">
        {error && <div className="luxiaFormError" role="alert">{error}</div>}
        <label className="luxiaField">
          <span>Correo electrónico</span>
          <div className="luxiaInputWrap">
            <i><MailIcon /></i>
            <input name="email" type="email" autoComplete="email" required placeholder="usuario@correo.com" />
          </div>
        </label>
        <label className="luxiaField">
          <span className="luxiaFieldRow">Contraseña <small>Acceso protegido</small></span>
          <div className="luxiaInputWrap">
            <i><LockIcon /></i>
            <input name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" required minLength={8} placeholder="••••••••••••" />
            <button type="button" className="luxiaPasswordToggle" onClick={() => setShowPassword((value) => !value)} aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}><EyeIcon /></button>
          </div>
        </label>
        <div className="luxiaFormMeta">
          <label><input type="checkbox" /> <span>Recordarme</span></label>
          <Link href="/forgot-password">¿Olvidaste tu contraseña?</Link>
        </div>
        <button className="luxiaPrimaryButton" disabled={loading}>{loading ? "Verificando acceso…" : "Entrar a la aplicación"}</button>
      </form>
      <p className="luxiaSwitchAuth">¿Aún no tienes cuenta? <Link href="/register">Crear cuenta</Link></p>
    </>
  );
}
