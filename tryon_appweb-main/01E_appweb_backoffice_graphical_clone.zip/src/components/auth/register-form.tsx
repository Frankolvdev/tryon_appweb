"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { register } from "@/lib/auth-api";
import { SocialProviders } from "@/components/auth/social-providers";

function UserIcon() { return <svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4.1 3.4-6 8-6s7.2 1.9 8 6"/></svg>; }
function MailIcon() { return <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>; }
function LockIcon() { return <svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>; }

export function RegisterForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");
    const data = new FormData(event.currentTarget);
    if (data.get("password") !== data.get("confirmPassword")) return setError("Las contraseñas no coinciden.");
    if (!data.get("terms")) return setError("Debes aceptar los términos y la política de privacidad.");
    setLoading(true);
    try {
      await register({ full_name: String(data.get("fullName")), email: String(data.get("email")), password: String(data.get("password")) });
      router.push("/login?registered=1");
    } catch (err) {
      setError(err instanceof Error ? err.message : "No fue posible crear la cuenta.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <>
      <SocialProviders />
      <form onSubmit={submit} className="luxiaAuthForm">
        {error && <div className="luxiaFormError" role="alert">{error}</div>}
        <label className="luxiaField"><span>Nombre completo</span><div className="luxiaInputWrap"><i><UserIcon /></i><input name="fullName" required autoComplete="name" placeholder="Tu nombre" /></div></label>
        <label className="luxiaField"><span>Correo electrónico</span><div className="luxiaInputWrap"><i><MailIcon /></i><input name="email" type="email" required autoComplete="email" placeholder="usuario@correo.com" /></div></label>
        <div className="luxiaTwoCols">
          <label className="luxiaField"><span>Contraseña</span><div className="luxiaInputWrap"><i><LockIcon /></i><input name="password" type="password" required minLength={8} autoComplete="new-password" placeholder="••••••••" /></div></label>
          <label className="luxiaField"><span>Confirmar</span><div className="luxiaInputWrap"><i><LockIcon /></i><input name="confirmPassword" type="password" required minLength={8} autoComplete="new-password" placeholder="••••••••" /></div></label>
        </div>
        <label className="luxiaTerms"><input type="checkbox" name="terms" /><span>Acepto los <Link href="/terms">Términos</Link> y la <Link href="/privacy">Política de privacidad</Link>.</span></label>
        <button className="luxiaPrimaryButton" disabled={loading}>{loading ? "Creando cuenta…" : "Crear cuenta"}</button>
      </form>
      <p className="luxiaSwitchAuth">¿Ya tienes cuenta? <Link href="/login">Iniciar sesión</Link></p>
    </>
  );
}
