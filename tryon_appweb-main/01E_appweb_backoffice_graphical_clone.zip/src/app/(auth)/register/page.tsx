import { AuthShell } from "@/components/auth/auth-shell";
import { RegisterForm } from "@/components/auth/register-form";

export default function RegisterPage() {
  return (
    <AuthShell
      eyebrow="Crea tu espacio personal para generar, organizar y guardar tus resultados."
      title="Crea tu cuenta"
      description="Explora nuevas combinaciones, prueba prendas y construye una biblioteca visual con inteligencia artificial."
    >
      <RegisterForm />
    </AuthShell>
  );
}
