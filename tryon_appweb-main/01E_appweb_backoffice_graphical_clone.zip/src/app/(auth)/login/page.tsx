import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "@/components/auth/login-form";

export default function LoginPage() {
  return (
    <AuthShell
      eyebrow="Accede a tu estudio creativo y continúa donde lo dejaste."
      title="Bienvenido de nuevo"
      description="Convierte tus fotografías, prendas e ideas en una experiencia visual completamente nueva."
    >
      <LoginForm />
    </AuthShell>
  );
}
