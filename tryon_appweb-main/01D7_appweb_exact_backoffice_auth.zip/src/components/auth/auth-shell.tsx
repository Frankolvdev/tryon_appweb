import type { ReactNode } from "react";

const securityItems = [
  { icon: "shield", label: "Cuenta protegida" },
  { icon: "lock", label: "Sesión segura" },
  { icon: "spark", label: "Procesamiento privado" },
  { icon: "image", label: "Resultados en tiempo real" },
] as const;

function Icon({ name }: { name: string }) {
  const paths: Record<string, ReactNode> = {
    shield: <><path d="M12 3 5 6v5c0 4.7 2.9 8.1 7 10 4.1-1.9 7-5.3 7-10V6l-7-3Z"/><path d="m9.5 12 1.7 1.7 3.6-3.9"/></>,
    lock: <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>,
    spark: <><path d="m12 3 1.4 4.1L17.5 8.5l-4.1 1.4L12 14l-1.4-4.1-4.1-1.4 4.1-1.4L12 3Z"/><path d="m18 14 .8 2.2L21 17l-2.2.8L18 20l-.8-2.2L15 17l2.2-.8L18 14Z"/></>,
    image: <><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="8.5" cy="9" r="1.5"/><path d="m21 15-5-5L5 20"/></>,
  };
  return <svg viewBox="0 0 24 24" aria-hidden="true">{paths[name]}</svg>;
}

export function AuthShell({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children: ReactNode }) {
  return (
    <main className="boAuthPage">
      <section className="boAuthHero luxia-grid-background">
        <div className="boBrand">
          <span className="boBrandMark">T</span>
          <span className="boBrandName">TRYON<span>AI</span></span>
        </div>

        <div className="boHeroContent">
          <div className="boHeroBadge"><span>AI Fashion Studio</span></div>
          <p className="boHeroKicker">Estudio personal</p>
          <h1 className="luxia-text-gradient">Inteligencia,<br />estilo y creatividad.</h1>
          <p className="boHeroDescription">{description}</p>
          <div className="boSecurityGrid">
            {securityItems.map((item) => (
              <div className="boSecurityItem" key={item.label}>
                <span className="boSecurityIcon"><Icon name={item.icon} /></span>
                <span>{item.label}</span>
              </div>
            ))}
          </div>
        </div>

        <p className="boHeroFootnote">Experiencia privada · Procesamiento seguro · Resultados únicos</p>
      </section>

      <section className="boAuthSide">
        <div className="boAuthCard luxia-panel">
          <div className="boCardBrand">
            <span className="boBrandMark boBrandMarkSmall">T</span>
            <div><strong>TRYON<span>AI</span></strong><small>Aplicación web</small></div>
          </div>
          <div className="boRestrictedBadge"><span /> Acceso de usuario</div>
          <div className="boCardHeading">
            <p>{eyebrow}</p>
            <h2>{title}</h2>
          </div>
          {children}
          <p className="boAuditNote">Tu sesión y tus operaciones se protegen mediante los controles de seguridad de la plataforma.</p>
        </div>
      </section>
    </main>
  );
}
