"use client";

import Link from "next/link";
import { FormEvent, useMemo, useState } from "react";
import { confirmPasswordRecovery } from "@/lib/password-recovery-api";

function Icon({
  type,
}: {
  type: "lock" | "eye" | "eyeoff" | "check" | "alert";
}) {
  const props = {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    "aria-hidden": true,
  };

  if (type === "lock") {
    return (
      <svg {...props}>
        <rect x="5" y="10" width="14" height="10" rx="2" />
        <path d="M8 10V7a4 4 0 0 1 8 0v3" />
      </svg>
    );
  }

  if (type === "check") {
    return (
      <svg {...props}>
        <circle cx="12" cy="12" r="9" />
        <path d="m8.5 12 2.3 2.3 4.8-5" />
      </svg>
    );
  }

  if (type === "alert") {
    return (
      <svg {...props}>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 8v5M12 16h.01" />
      </svg>
    );
  }

  if (type === "eyeoff") {
    return (
      <svg {...props}>
        <path d="m3 3 18 18" />
        <path d="M10.6 10.7a2 2 0 0 0 2.7 2.7" />
        <path d="M9.9 4.2A10.8 10.8 0 0 1 12 4c5.5 0 9 5 9 5a16 16 0 0 1-2.1 2.6M6.6 6.6C4.3 8 3 10 3 10s3.5 5 9 5a10 10 0 0 0 3.4-.6" />
      </svg>
    );
  }

  return (
    <svg {...props}>
      <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z" />
      <circle cx="12" cy="12" r="2.5" />
    </svg>
  );
}

export function ResetPasswordForm({
  email,
  token,
  otp,
}: {
  email: string;
  token?: string;
  otp?: string;
}) {
  const [password, setPassword] = useState("");
  const [confirmation, setConfirmation] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState("");

  const rules = useMemo(
    () => ({
      length: password.length >= 8,
      upper: /[A-Z]/.test(password),
      lower: /[a-z]/.test(password),
      number: /\d/.test(password),
      symbol: /[^A-Za-z0-9]/.test(password),
      match: password.length > 0 && password === confirmation,
    }),
    [password, confirmation],
  );

  const strength = Math.round(
    (Object.values(rules).filter(Boolean).length / 6) * 100,
  );

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError("");

    if (!email || (!token && !otp)) {
      setError("El enlace está incompleto o ya no es válido. Solicita uno nuevo.");
      return;
    }

    if (!Object.values(rules).every(Boolean)) {
      setError("Completa todos los requisitos antes de continuar.");
      return;
    }

    setLoading(true);

    try {
      await confirmPasswordRecovery({
        email,
        token,
        otp,
        newPassword: password,
      });
      setCompleted(true);
    } catch (reason) {
      setError(
        reason instanceof Error
          ? reason.message
          : "El enlace no es válido o ya expiró.",
      );
    } finally {
      setLoading(false);
    }
  }

  if (completed) {
    return (
      <div className="boRecoveryState">
        <div className="boRecoveryIcon boRecoveryIconSuccess">
          <Icon type="check" />
        </div>

        <h3>Contraseña actualizada</h3>

        <p className="boRecoveryDescription">
          Tu cuenta vuelve a estar protegida. Ya puedes iniciar sesión con tu
          nueva contraseña.
        </p>

        <Link className="boPrimaryButton boRecoveryLinkButton" href="/login">
          Iniciar sesión
        </Link>
      </div>
    );
  }

  const ruleClass = (valid: boolean) =>
    `boRecoveryRule${valid ? " boRecoveryRuleValid" : ""}`;

  return (
    <form className="boAuthForm" onSubmit={submit}>
      <label className="boField" htmlFor="new-password">
        Nueva contraseña
        <span className="boInputWrap boRecoveryPasswordInput">
          <i>
            <Icon type="lock" />
          </i>
          <input
            id="new-password"
            type={showPassword ? "text" : "password"}
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Crea una contraseña segura"
            autoComplete="new-password"
            autoFocus
          />
          <button
            type="button"
            className="boRecoveryEye"
            onClick={() => setShowPassword((value) => !value)}
            aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
          >
            <Icon type={showPassword ? "eyeoff" : "eye"} />
          </button>
        </span>
      </label>

      <div className="boRecoveryStrength">
        <div>
          <span>Fortaleza de la contraseña</span>
          <strong>
            {strength === 100
              ? "Excelente"
              : strength >= 67
                ? "Buena"
                : strength >= 34
                  ? "Media"
                  : "Débil"}
          </strong>
        </div>
        <span className="boRecoveryStrengthTrack">
          <span style={{ width: `${strength}%` }} />
        </span>
      </div>

      <label className="boField" htmlFor="confirm-password">
        Confirmar contraseña
        <span className="boInputWrap">
          <i>
            <Icon type="lock" />
          </i>
          <input
            id="confirm-password"
            type={showPassword ? "text" : "password"}
            value={confirmation}
            onChange={(event) => setConfirmation(event.target.value)}
            placeholder="Repite la contraseña"
            autoComplete="new-password"
          />
        </span>
      </label>

      <div className="boRecoveryRequirements">
        <span className={ruleClass(rules.length)}>8 caracteres</span>
        <span className={ruleClass(rules.upper)}>Una mayúscula</span>
        <span className={ruleClass(rules.lower)}>Una minúscula</span>
        <span className={ruleClass(rules.number)}>Un número</span>
        <span className={ruleClass(rules.symbol)}>Un símbolo</span>
        <span className={ruleClass(rules.match)}>
          Las contraseñas coinciden
        </span>
      </div>

      {error ? (
        <div className="boFormError boRecoveryMessage" role="alert">
          <Icon type="alert" />
          <p>{error}</p>
        </div>
      ) : null}

      <button type="submit" className="boPrimaryButton" disabled={loading}>
        {loading ? "Actualizando protección…" : "Guardar nueva contraseña"}
      </button>

      <p className="boSwitchAuth">
        <Link href="/forgot-password">Solicitar otro enlace</Link>
      </p>
    </form>
  );
}
