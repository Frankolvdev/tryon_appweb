"use client";
import { env } from "@/lib/env";

export function SocialProviders() {
  const startGoogle = () => {
    if (!env.googleOAuthStartUrl) {
      window.alert("Google OAuth aún no está configurado. Completa NEXT_PUBLIC_GOOGLE_OAUTH_START_URL siguiendo GOOGLE_OAUTH_SETUP.md.");
      return;
    }
    const returnTo = encodeURIComponent(`${env.appUrl}/oauth/callback`);
    const separator = env.googleOAuthStartUrl.includes("?") ? "&" : "?";
    window.location.assign(`${env.googleOAuthStartUrl}${separator}return_to=${returnTo}`);
  };
  return (
    <>
      <button type="button" className="luxiaGoogleButton" onClick={startGoogle}>
        <svg viewBox="0 0 24 24" aria-hidden="true"><path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.4-.18-2.07H12v3.92h5.38a4.6 4.6 0 0 1-2 3.02v2.54h3.24c1.9-1.75 2.98-4.33 2.98-7.41Z"/><path fill="#34A853" d="M12 22c2.7 0 4.97-.9 6.62-2.36l-3.24-2.54c-.9.6-2.05.96-3.38.96-2.61 0-4.82-1.76-5.61-4.13H3.04v2.62A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.39 13.93A6.02 6.02 0 0 1 6.07 12c0-.67.12-1.32.32-1.93V7.45H3.04A10 10 0 0 0 2 12c0 1.61.39 3.14 1.04 4.55l3.35-2.62Z"/><path fill="#EA4335" d="M12 5.94c1.47 0 2.79.5 3.83 1.5l2.87-2.87A9.62 9.62 0 0 0 12 2a10 10 0 0 0-8.96 5.45l3.35 2.62C7.18 7.7 9.39 5.94 12 5.94Z"/></svg>
        Continuar con Google
      </button>
      <div className="luxiaAuthDivider"><span>o continúa con correo</span></div>
    </>
  );
}
