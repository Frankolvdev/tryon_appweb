"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { login } from "@/lib/auth-api";
import { saveSession } from "@/lib/auth-storage";
import { SocialProviders } from "@/components/auth/social-providers";

function MailIcon(){return <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>}
function LockIcon(){return <svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>}
function EyeIcon({off=false}:{off?:boolean}){return off?<svg viewBox="0 0 24 24"><path d="m3 3 18 18"/><path d="M10.6 10.7a2 2 0 0 0 2.7 2.7"/><path d="M9.9 4.2A10.5 10.5 0 0 1 12 4c5 0 9 5 9 8a8.8 8.8 0 0 1-2 3.7M6.2 6.2C4.2 7.5 3 10 3 12c0 3 4 8 9 8 1.2 0 2.4-.3 3.4-.8"/></svg>:<svg viewBox="0 0 24 24"><path d="M3 12c0-3 4-8 9-8s9 5 9 8-4 8-9 8-9-5-9-8Z"/><circle cx="12" cy="12" r="2.5"/></svg>}

export function LoginForm(){
 const router=useRouter(); const[loading,setLoading]=useState(false); const[error,setError]=useState(""); const[show,setShow]=useState(false);
 async function submit(event:React.FormEvent<HTMLFormElement>){event.preventDefault();setError("");setLoading(true);const data=new FormData(event.currentTarget);try{const token=await login(String(data.get("email")),String(data.get("password")));saveSession(token.access_token,token.refresh_token);router.replace("/dashboard")}catch(err){setError(err instanceof Error?err.message:"No fue posible iniciar sesión.")}finally{setLoading(false)}}
 return <>
   <SocialProviders />
   <form className="luxiaAuthForm" onSubmit={submit}>
     {error&&<div className="luxiaAuthError" role="alert">{error}</div>}
     <label className="luxiaAuthField"><span>Correo electrónico</span><div className="luxiaAuthInput"><i><MailIcon/></i><input name="email" type="email" autoComplete="email" required placeholder="usuario@correo.com"/></div></label>
     <label className="luxiaAuthField"><span className="luxiaAuthFieldHeader">Contraseña <small>Acceso protegido</small></span><div className="luxiaAuthInput"><i><LockIcon/></i><input name="password" type={show?"text":"password"} autoComplete="current-password" required minLength={8} placeholder="••••••••••••"/><button type="button" className="luxiaEyeButton" onClick={()=>setShow(v=>!v)} aria-label={show?"Ocultar contraseña":"Mostrar contraseña"}><EyeIcon off={show}/></button></div></label>
     <div className="luxiaAuthMeta"><label><input type="checkbox"/><span>Recordarme</span></label><Link href="/forgot-password">¿Olvidaste tu contraseña?</Link></div>
     <button className="luxiaAuthSubmit" disabled={loading}>{loading?"Verificando acceso…":"Entrar a LUXIA"}</button>
   </form>
   <p className="luxiaAuthSwitch">¿Aún no tienes cuenta? <Link href="/register">Crear cuenta</Link></p>
 </>
}
