import type { ReactNode } from "react";

const items = [
  ["shield", "Cuenta protegida"],
  ["lock", "Sesión segura"],
  ["activity", "Procesamiento privado"],
  ["database", "Datos en tiempo real"],
] as const;

function Icon({ name }: { name: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      {name === "shield" && <><path d="M12 3 5 6v5c0 4.7 2.9 8.1 7 10 4.1-1.9 7-5.3 7-10V6l-7-3Z"/><path d="m9.5 12 1.7 1.7 3.6-3.9"/></>}
      {name === "lock" && <><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></>}
      {name === "activity" && <path d="M3 12h4l2-6 4 12 2-6h6"/>}
      {name === "database" && <><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5"/><path d="M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/></>}
    </svg>
  );
}

export function AuthShell({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children: ReactNode }) {
  return (
    <main className="backofficeAuthRoot">
      <div className="backofficeGrid" />
      <div className="backofficeGlow backofficeGlowTop" />
      <div className="backofficeGlow backofficeGlowBottom" />

      <div className="backofficeAuthLayout">
        <section className="backofficeAuthHero">
          <div>
            <div className="backofficeLogo">
              <div className="backofficeLogoIcon">T</div>
              <div>
                <strong>TRYONAI</strong>
                <span>AI FASHION STUDIO</span>
              </div>
            </div>

            <div className="backofficeHeroCopy">
              <p>ESTUDIO CREATIVO</p>
              <h1>Inteligencia,<br />estilo y creatividad.</h1>
              <div className="backofficeHeroDescription">{description}</div>
            </div>
          </div>

          <div className="backofficeFeatureGrid">
            {items.map(([icon, label]) => (
              <div className="backofficeFeature" key={label}>
                <Icon name={icon} />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="backofficeAuthFormSide">
          <div className="backofficeMobileLogo">
            <div className="backofficeLogoIcon">T</div>
            <div><strong>TRYONAI</strong><span>APP WEB</span></div>
          </div>

          <div className="backofficeAuthCard">
            <div className="backofficeLockIcon"><Icon name="lock" /></div>
            <p className="backofficeRestricted">ACCESO DE USUARIO</p>
            <h2>{title}</h2>
            <p className="backofficeSubtitle">{eyebrow}</p>
            {children}
          </div>
          <p className="backofficeAudit">Tu sesión y tus operaciones quedan protegidas por los controles de seguridad de la plataforma.</p>
        </section>
      </div>
    </main>
  );
}
