"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { login } from "@/lib/auth-api";
import { saveSession } from "@/lib/auth-storage";
import { SocialProviders } from "@/components/auth/social-providers";

function MailIcon() { return <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/></svg>; }
function LockIcon() { return <svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>; }

export function LoginForm() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault(); setError(""); setLoading(true);
    const data = new FormData(event.currentTarget);
    try {
      const token = await login(String(data.get("email")), String(data.get("password")));
      saveSession(token.access_token, token.refresh_token);
      router.replace("/dashboard");
    } catch (err) { setError(err instanceof Error ? err.message : "No fue posible iniciar sesión."); }
    finally { setLoading(false); }
  }

  return (
    <>
      <SocialProviders />
      <form onSubmit={submit} className="boAuthForm">
        {error && <div className="boFormError" role="alert">{error}</div>}
        <label className="boField">
          <span>Correo electrónico</span>
          <div className="boInputWrap"><i><MailIcon /></i><input name="email" type="email" autoComplete="email" required placeholder="usuario@correo.com" /></div>
        </label>
        <label className="boField">
          <span className="boFieldRow">Contraseña <small>Acceso protegido</small></span>
          <div className="boInputWrap"><i><LockIcon /></i><input name="password" type="password" autoComplete="current-password" required minLength={8} placeholder="••••••••••••" /></div>
        </label>
        <div className="boFormMeta"><label><input type="checkbox" /> <span>Recordarme</span></label><Link href="/forgot-password">¿Olvidaste tu contraseña?</Link></div>
        <button className="boPrimaryButton" disabled={loading}>{loading ? "Verificando acceso…" : "Entrar a TryOn"}</button>
      </form>
      <p className="boSwitchAuth">¿Aún no tienes cuenta? <Link href="/register">Crear cuenta</Link></p>
    </>
  );
}
