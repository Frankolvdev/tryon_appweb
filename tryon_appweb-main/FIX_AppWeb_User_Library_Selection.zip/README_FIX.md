# FIX AppWeb: selección de archivos desde biblioteca

La selección deja de hacer `fetch()` directo a la URL de R2/S3 y usa el endpoint autenticado del Backend.
Incluye manejo visible de errores y evita `unhandledRejection`.
