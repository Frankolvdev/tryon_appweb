# HOTFIX AppWeb43 — Create Model IA / Body + Timeline + Ancestry R5

Base: `tryon_appweb-main (43).zip` — usar la copia exterior del proyecto.

## Cambios
- Elimina el nodo horizontal `Rasgos` del flujo Create Identity.
- Elimina la barra `MODO DE IDENTIDAD / Crear identidad` sobre la timeline.
- Cambia el encabezado Step 02 a `Crea un cuerpo`.
- Nombre superior queda de solo lectura; se edita únicamente en Paso 01.
- Timeline: nodos completados siempre se pueden reabrir; nodos no completados siguen bloqueados.
- Al confirmar un nodo se avanza al nodo inmediato siguiente, sin saltarse nodos ya completados.
- Ascendencia: retry de carga del catálogo para fallos transitorios iniciales.
- Ascendencia: reemplaza `scrollIntoView()` por scroll interno del carrusel para evitar que el card/layout se desplace lateralmente al elegir un país.
- Complexion: elimina el texto superior `Complexion`.
- Complexion: Slim/Thick muestran sus previews siempre que existan assets publicados en Backend, no solo al seleccionarlos.
- Complexion: preview ya no se renderiza opaco.
- Elimina botones `Fit / Curvy` de Butt Size.
- Valores temporales de sliders se muestran numéricos y pequeños.
- Etiquetas de extremos:
  - Hips: Small / Huge
  - Butt Size: Small / Huge
  - Breasts: Small / Huge
  - Height: Very short / Very tall
  - Bubble Butt: Low lift / High lift
  - Waist: Very narrow / Very wide
- Mantiene step 0.2 en sliders continuos.

## Archivos
- `src/components/models/body-proportions-step.tsx`
- `src/components/models/face-studio.tsx`
- `src/components/models/ancestry-experience.tsx`
- `src/components/models/model-studio.tsx`
- `src/app/globals.css`

## Validación
No se modificó Backend, contratos de Generation Modules, pricing, tokens, Modal recovery ni Owner Local.

En este entorno no fue posible completar `npm run build` porque `node_modules` no venía en el ZIP y la instalación `npm ci` excedió el límite de ejecución del entorno. Ejecutar localmente el build protegido antes de commit/push.
