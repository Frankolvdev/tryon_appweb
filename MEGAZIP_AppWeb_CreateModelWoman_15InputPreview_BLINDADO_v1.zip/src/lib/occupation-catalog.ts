export type OccupationLocale = "es" | "en";
export type OccupationOption = { id: string; es: string; en: string };

export const OCCUPATIONS: OccupationOption[] = [
  { id: "doctor", es: "Doctora", en: "Doctor" },
  { id: "nurse", es: "Enfermera", en: "Nurse" },
  { id: "teacher", es: "Profesora", en: "Teacher" },
  { id: "engineer", es: "Ingeniera", en: "Engineer" },
  { id: "lawyer", es: "Abogada", en: "Lawyer" },
  { id: "business-owner", es: "Empresaria", en: "Business Owner" },
  { id: "student", es: "Estudiante", en: "Student" },
  { id: "software-developer", es: "Desarrolladora de software", en: "Software Developer" },
  { id: "architect", es: "Arquitecta", en: "Architect" },
  { id: "chef", es: "Chef", en: "Chef" },
  { id: "photographer", es: "Fotógrafa", en: "Photographer" },
  { id: "model", es: "Modelo", en: "Model" },
  { id: "accountant", es: "Contadora", en: "Accountant" },
  { id: "administrator", es: "Administradora", en: "Administrator" },
  { id: "salesperson", es: "Vendedora", en: "Salesperson" },
  { id: "marketing-specialist", es: "Especialista en marketing", en: "Marketing Specialist" },
  { id: "graphic-designer", es: "Diseñadora gráfica", en: "Graphic Designer" },
  { id: "web-designer", es: "Diseñadora web", en: "Web Designer" },
  { id: "data-analyst", es: "Analista de datos", en: "Data Analyst" },
  { id: "data-scientist", es: "Científica de datos", en: "Data Scientist" },
  { id: "product-manager", es: "Gerente de producto", en: "Product Manager" },
  { id: "project-manager", es: "Gerente de proyectos", en: "Project Manager" },
  { id: "human-resources", es: "Profesional de recursos humanos", en: "Human Resources Professional" },
  { id: "recruiter", es: "Reclutadora", en: "Recruiter" },
  { id: "psychologist", es: "Psicóloga", en: "Psychologist" },
  { id: "therapist", es: "Terapeuta", en: "Therapist" },
  { id: "dentist", es: "Dentista", en: "Dentist" },
  { id: "pharmacist", es: "Farmacéutica", en: "Pharmacist" },
  { id: "veterinarian", es: "Veterinaria", en: "Veterinarian" },
  { id: "surgeon", es: "Cirujana", en: "Surgeon" },
  { id: "paramedic", es: "Paramédica", en: "Paramedic" },
  { id: "physical-therapist", es: "Fisioterapeuta", en: "Physical Therapist" },
  { id: "nutritionist", es: "Nutrióloga", en: "Nutritionist" },
  { id: "scientist", es: "Científica", en: "Scientist" },
  { id: "researcher", es: "Investigadora", en: "Researcher" },
  { id: "biologist", es: "Bióloga", en: "Biologist" },
  { id: "chemist", es: "Química", en: "Chemist" },
  { id: "physicist", es: "Física", en: "Physicist" },
  { id: "civil-engineer", es: "Ingeniera civil", en: "Civil Engineer" },
  { id: "mechanical-engineer", es: "Ingeniera mecánica", en: "Mechanical Engineer" },
  { id: "electrical-engineer", es: "Ingeniera eléctrica", en: "Electrical Engineer" },
  { id: "industrial-engineer", es: "Ingeniera industrial", en: "Industrial Engineer" },
  { id: "aerospace-engineer", es: "Ingeniera aeroespacial", en: "Aerospace Engineer" },
  { id: "ai-engineer", es: "Ingeniera de IA", en: "AI Engineer" },
  { id: "cybersecurity-specialist", es: "Especialista en ciberseguridad", en: "Cybersecurity Specialist" },
  { id: "network-engineer", es: "Ingeniera de redes", en: "Network Engineer" },
  { id: "it-support", es: "Especialista de soporte TI", en: "IT Support Specialist" },
  { id: "database-administrator", es: "Administradora de bases de datos", en: "Database Administrator" },
  { id: "ux-designer", es: "Diseñadora UX", en: "UX Designer" },
  { id: "ui-designer", es: "Diseñadora UI", en: "UI Designer" },
  { id: "illustrator", es: "Ilustradora", en: "Illustrator" },
  { id: "animator", es: "Animadora", en: "Animator" },
  { id: "video-editor", es: "Editora de video", en: "Video Editor" },
  { id: "filmmaker", es: "Cineasta", en: "Filmmaker" },
  { id: "director", es: "Directora", en: "Director" },
  { id: "producer", es: "Productora", en: "Producer" },
  { id: "actor", es: "Actriz", en: "Actor" },
  { id: "musician", es: "Música", en: "Musician" },
  { id: "singer", es: "Cantante", en: "Singer" },
  { id: "dancer", es: "Bailarina", en: "Dancer" },
  { id: "writer", es: "Escritora", en: "Writer" },
  { id: "journalist", es: "Periodista", en: "Journalist" },
  { id: "content-creator", es: "Creadora de contenido", en: "Content Creator" },
  { id: "influencer", es: "Influencer", en: "Influencer" },
  { id: "social-media-manager", es: "Social Media Manager", en: "Social Media Manager" },
  { id: "public-relations", es: "Especialista en relaciones públicas", en: "Public Relations Specialist" },
  { id: "copywriter", es: "Redactora publicitaria", en: "Copywriter" },
  { id: "translator", es: "Traductora", en: "Translator" },
  { id: "interpreter", es: "Intérprete", en: "Interpreter" },
  { id: "librarian", es: "Bibliotecaria", en: "Librarian" },
  { id: "professor", es: "Catedrática", en: "Professor" },
  { id: "school-principal", es: "Directora escolar", en: "School Principal" },
  { id: "coach", es: "Entrenadora", en: "Coach" },
  { id: "personal-trainer", es: "Entrenadora personal", en: "Personal Trainer" },
  { id: "athlete", es: "Atleta", en: "Athlete" },
  { id: "yoga-instructor", es: "Instructora de yoga", en: "Yoga Instructor" },
  { id: "fitness-instructor", es: "Instructora fitness", en: "Fitness Instructor" },
  { id: "police-officer", es: "Policía", en: "Police Officer" },
  { id: "firefighter", es: "Bombera", en: "Firefighter" },
  { id: "military-officer", es: "Militar", en: "Military Officer" },
  { id: "security-guard", es: "Guardia de seguridad", en: "Security Guard" },
  { id: "detective", es: "Detective", en: "Detective" },
  { id: "judge", es: "Jueza", en: "Judge" },
  { id: "paralegal", es: "Jurídica", en: "Paralegal" },
  { id: "real-estate-agent", es: "Agente inmobiliario", en: "Real Estate Agent" },
  { id: "insurance-agent", es: "Agente de seguros", en: "Insurance Agent" },
  { id: "banker", es: "Banquera", en: "Banker" },
  { id: "financial-advisor", es: "Asesora financiera", en: "Financial Advisor" },
  { id: "economist", es: "Economista", en: "Economist" },
  { id: "investment-analyst", es: "Analista de inversiones", en: "Investment Analyst" },
  { id: "entrepreneur", es: "Emprendedora", en: "Entrepreneur" },
  { id: "consultant", es: "Consultora", en: "Consultant" },
  { id: "operations-manager", es: "Gerente de operaciones", en: "Operations Manager" },
  { id: "store-manager", es: "Gerente de tienda", en: "Store Manager" },
  { id: "customer-service", es: "Representante de servicio al cliente", en: "Customer Service Representative" },
  { id: "receptionist", es: "Recepcionista", en: "Receptionist" },
  { id: "executive-assistant", es: "Asistente ejecutiva", en: "Executive Assistant" },
  { id: "secretary", es: "Secretaria", en: "Secretary" },
  { id: "office-worker", es: "Oficinista", en: "Office Worker" },
  { id: "barista", es: "Barista", en: "Barista" },
  { id: "bartender", es: "Bartender", en: "Bartender" },
  { id: "waiter", es: "Mesera", en: "Waiter / Waitress" },
  { id: "baker", es: "Panadera", en: "Baker" },
  { id: "pastry-chef", es: "Repostera", en: "Pastry Chef" },
  { id: "butcher", es: "Carnicera", en: "Butcher" },
  { id: "farmer", es: "Agricultora", en: "Farmer" },
  { id: "gardener", es: "Jardinera", en: "Gardener" },
  { id: "florist", es: "Florista", en: "Florist" },
  { id: "fashion-designer", es: "Diseñadora de moda", en: "Fashion Designer" },
  { id: "stylist", es: "Estilista", en: "Stylist" },
  { id: "hair-stylist", es: "Estilista de cabello", en: "Hair Stylist" },
  { id: "makeup-artist", es: "Maquillista", en: "Makeup Artist" },
  { id: "nail-technician", es: "Técnica de uñas", en: "Nail Technician" },
  { id: "esthetician", es: "Esteticista", en: "Esthetician" },
  { id: "tailor", es: "Modista", en: "Tailor" },
  { id: "jeweler", es: "Joyera", en: "Jeweler" },
  { id: "interior-designer", es: "Diseñadora de interiores", en: "Interior Designer" },
  { id: "construction-worker", es: "Trabajadora de construcción", en: "Construction Worker" },
  { id: "carpenter", es: "Carpintera", en: "Carpenter" },
  { id: "electrician", es: "Electricista", en: "Electrician" },
  { id: "plumber", es: "Plomera", en: "Plumber" },
  { id: "welder", es: "Soldadora", en: "Welder" },
  { id: "mechanic", es: "Mecánica automotriz", en: "Mechanic" },
  { id: "truck-driver", es: "Conductora de camión", en: "Truck Driver" },
  { id: "delivery-driver", es: "Repartidora", en: "Delivery Driver" },
  { id: "taxi-driver", es: "Taxista", en: "Taxi Driver" },
  { id: "pilot", es: "Piloto", en: "Pilot" },
  { id: "flight-attendant", es: "Auxiliar de vuelo", en: "Flight Attendant" },
  { id: "travel-agent", es: "Agente de viajes", en: "Travel Agent" },
  { id: "tour-guide", es: "Guía turística", en: "Tour Guide" },
  { id: "hotel-manager", es: "Gerente de hotel", en: "Hotel Manager" },
  { id: "housekeeper", es: "Personal de limpieza", en: "Housekeeper" },
  { id: "caregiver", es: "Cuidadora", en: "Caregiver" },
  { id: "social-worker", es: "Trabajadora social", en: "Social Worker" },
  { id: "childcare-worker", es: "Cuidadora infantil", en: "Childcare Worker" },
  { id: "stay-at-home-parent", es: "Madre dedicada al hogar", en: "Stay-at-Home Parent" },
  { id: "retired", es: "Jubilada", en: "Retired" },
  { id: "freelancer", es: "Freelancer", en: "Freelancer" },
  { id: "remote-worker", es: "Trabajadora remota", en: "Remote Worker" },
  { id: "unemployed", es: "Sin empleo", en: "Unemployed" },
];

export function getOccupationLabel(id: string | undefined, locale: OccupationLocale = "es") {
  if (!id) return "";
  const option = OCCUPATIONS.find((item) => item.id === id);
  return option ? option[locale] : "";
}

export function getOccupationPromptValue(id: string | undefined, customValue?: string) {
  if (!id) return "";
  if (id === "custom") return customValue?.trim() || "";
  return OCCUPATIONS.find((item) => item.id === id)?.en || "";
}

export type OccupationGenerationContext = {
  place: string;
  clothes: string;
};

const OCCUPATION_CONTEXT_GROUPS: Array<{
  ids: string[];
  place: string;
  clothes: string;
}> = [
  {
    ids: ["doctor", "nurse", "dentist", "pharmacist", "surgeon", "paramedic", "physical-therapist", "nutritionist", "caregiver"],
    place: "modern bright hospital or medical clinic interior",
    clothes: "stylish fitted professional medical uniform, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["veterinarian"],
    place: "modern veterinary clinic interior",
    clothes: "stylish fitted veterinary medical uniform, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["teacher", "professor", "school-principal", "librarian", "student"],
    place: "modern elegant school or university interior",
    clothes: "stylish fitted smart academic outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["software-developer", "data-analyst", "data-scientist", "product-manager", "project-manager", "ai-engineer", "cybersecurity-specialist", "network-engineer", "it-support", "database-administrator", "ux-designer", "ui-designer", "web-designer", "remote-worker"],
    place: "modern technology office with elegant workstations",
    clothes: "stylish fitted smart-casual professional outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["engineer", "architect", "civil-engineer", "mechanical-engineer", "electrical-engineer", "industrial-engineer", "aerospace-engineer"],
    place: "modern professional design and engineering studio",
    clothes: "stylish fitted professional engineering outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["lawyer", "judge", "paralegal"],
    place: "elegant modern law office interior",
    clothes: "elegant fitted professional suit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["business-owner", "accountant", "administrator", "marketing-specialist", "human-resources", "recruiter", "banker", "financial-advisor", "economist", "investment-analyst", "entrepreneur", "consultant", "operations-manager", "customer-service", "receptionist", "executive-assistant", "secretary", "office-worker"],
    place: "elegant modern corporate office interior",
    clothes: "elegant fitted office outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["salesperson", "store-manager"],
    place: "modern upscale retail store interior",
    clothes: "stylish fitted retail professional outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["psychologist", "therapist", "social-worker"],
    place: "warm modern private consultation office",
    clothes: "soft elegant fitted professional outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["scientist", "researcher", "biologist", "chemist", "physicist"],
    place: "clean modern research laboratory",
    clothes: "fitted professional laboratory outfit with clean lab coat, tasteful, fully covered, realistic",
  },
  {
    ids: ["chef", "baker", "pastry-chef", "butcher"],
    place: "modern professional kitchen interior",
    clothes: "stylish fitted chef uniform, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["barista", "bartender", "waiter"],
    place: "stylish upscale cafe or restaurant interior",
    clothes: "stylish fitted hospitality uniform, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["photographer", "graphic-designer", "illustrator", "animator", "video-editor", "filmmaker", "director", "producer", "writer", "journalist", "copywriter", "translator", "interpreter"],
    place: "stylish modern creative studio interior",
    clothes: "fashionable fitted creative-professional outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["model", "actor", "musician", "singer", "dancer", "content-creator", "influencer", "social-media-manager", "public-relations"],
    place: "luxurious modern photo and content studio",
    clothes: "fashionable fitted contemporary outfit, glamorous but tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["coach", "personal-trainer", "athlete", "yoga-instructor", "fitness-instructor"],
    place: "premium modern fitness studio or gym",
    clothes: "stylish fitted athletic outfit, tasteful, fully covered, performance-ready and realistic",
  },
  {
    ids: ["police-officer", "security-guard", "detective"],
    place: "modern professional security or operations facility",
    clothes: "professional fitted duty uniform appropriate to the role, tasteful, fully covered and realistic",
  },
  {
    ids: ["firefighter"],
    place: "modern fire station interior",
    clothes: "professional fitted firefighter station uniform, tasteful, fully covered and realistic",
  },
  {
    ids: ["military-officer"],
    place: "modern military administrative facility",
    clothes: "professional fitted service uniform, tasteful, fully covered and realistic",
  },
  {
    ids: ["real-estate-agent", "insurance-agent", "travel-agent", "hotel-manager"],
    place: "luxurious modern client-facing office or hotel lobby",
    clothes: "elegant fitted business outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["fashion-designer", "stylist", "hair-stylist", "makeup-artist", "nail-technician", "esthetician", "tailor", "jeweler", "interior-designer", "florist"],
    place: "elegant modern fashion, beauty or design studio",
    clothes: "fashion-forward fitted professional outfit, tasteful, fully covered, polished and realistic",
  },
  {
    ids: ["construction-worker", "carpenter", "electrician", "plumber", "welder", "mechanic"],
    place: "clean modern workshop or active professional worksite",
    clothes: "fitted professional workwear appropriate to the role, tasteful, fully covered, practical and realistic",
  },
  {
    ids: ["farmer", "gardener"],
    place: "beautiful well-kept outdoor garden or farm setting",
    clothes: "stylish fitted practical outdoor workwear, tasteful, fully covered and realistic",
  },
  {
    ids: ["truck-driver", "delivery-driver", "taxi-driver"],
    place: "clean modern transport or logistics setting",
    clothes: "stylish fitted practical driver outfit, tasteful, fully covered and realistic",
  },
  {
    ids: ["pilot", "flight-attendant"],
    place: "modern premium airport or aircraft cabin setting",
    clothes: "elegant fitted aviation uniform appropriate to the role, tasteful, fully covered and realistic",
  },
  {
    ids: ["tour-guide"],
    place: "beautiful modern urban landmark setting",
    clothes: "stylish fitted smart-casual guide outfit, tasteful, fully covered and realistic",
  },
  {
    ids: ["housekeeper"],
    place: "luxurious modern hotel interior",
    clothes: "neat fitted professional housekeeping uniform, tasteful, fully covered and realistic",
  },
  {
    ids: ["childcare-worker", "stay-at-home-parent"],
    place: "bright comfortable modern home interior",
    clothes: "stylish fitted casual outfit, tasteful, fully covered, comfortable and realistic",
  },
  {
    ids: ["freelancer", "unemployed", "retired"],
    place: "elegant modern lifestyle interior",
    clothes: "stylish fitted smart-casual outfit, tasteful, fully covered, polished and realistic",
  },
];

export function getOccupationGenerationContext(
  id: string | undefined,
  customValue?: string,
): OccupationGenerationContext {
  if (id === "custom") {
    const occupation = customValue?.trim();
    return {
      place: occupation ? `modern professional environment appropriate for a ${occupation}` : "elegant modern professional interior",
      clothes: occupation
        ? `stylish fitted professional outfit appropriate for a ${occupation}, tasteful, fully covered, polished and realistic`
        : "stylish fitted professional outfit, tasteful, fully covered, polished and realistic",
    };
  }
  const group = OCCUPATION_CONTEXT_GROUPS.find((item) => item.ids.includes(id || ""));
  return group
    ? { place: group.place, clothes: group.clothes }
    : {
        place: "elegant modern professional interior",
        clothes: "stylish fitted professional outfit, tasteful, fully covered, polished and realistic",
      };
}
