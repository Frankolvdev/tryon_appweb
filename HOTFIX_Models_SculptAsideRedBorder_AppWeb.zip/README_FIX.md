HOTFIX — Sculpt card exact aside red + stronger fade

Only changes:
- Uses project action/aside red: #e11d35
- Border fades much earlier.
- Border reaches true transparent before the far-right edge.
- Internal gradient follows same color family.
- Existing 4-second sweep animation is unchanged.

No layout, spacing, scanner, sliders, Butt Elevation, gallery, persistence or backend changes.
