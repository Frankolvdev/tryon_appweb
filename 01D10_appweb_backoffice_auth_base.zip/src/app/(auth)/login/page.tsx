import { AuthShell } from "@/components/auth/auth-shell";
import { LoginForm } from "@/components/auth/login-form";

export default function LoginPage() {
  return (
    <AuthShell
      eyebrow="Accede a tu estudio creativo y continúa trabajando con tus looks, prendas y resultados."
      title="Bienvenido de nuevo"
      description="Transforma fotografías y prendas en nuevos estilos con una experiencia privada, rápida y completamente visual."
    >
      <LoginForm />
    </AuthShell>
  );
}
