import { AuthShell } from "@/components/auth/auth-shell";
import { RegisterForm } from "@/components/auth/register-form";

export default function RegisterPage() {
  return (
    <AuthShell
      eyebrow="Crea tu cuenta y empieza a construir tu guardarropa virtual con inteligencia artificial."
      title="Crea tu estudio personal"
      description="Experimenta con prendas, estilos y fotografías desde un espacio creativo diseñado para convertir tus ideas en resultados reales."
    >
      <RegisterForm />
    </AuthShell>
  );
}
